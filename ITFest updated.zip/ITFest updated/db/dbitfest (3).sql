-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 27, 2020 at 07:26 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbitfest`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_allocation`
--

CREATE TABLE IF NOT EXISTS `tbl_allocation` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `eventid` int(50) NOT NULL,
  `judgeid` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_allocation`
--

INSERT INTO `tbl_allocation` (`id`, `eventid`, `judgeid`) VALUES
(2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_coordinator`
--

CREATE TABLE IF NOT EXISTS `tbl_coordinator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `place` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_coordinator`
--

INSERT INTO `tbl_coordinator` (`id`, `name`, `address`, `contact`, `place`, `email`, `status`) VALUES
(1, 'Sruthy', 'wqusu', '6767676777', 'idukki', 'sruthy@gmail.com', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event`
--

CREATE TABLE IF NOT EXISTS `tbl_event` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `ename` varchar(50) NOT NULL,
  `edate` date NOT NULL,
  `venue` varchar(50) NOT NULL,
  `etime` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_event`
--

INSERT INTO `tbl_event` (`id`, `ename`, `edate`, `venue`, `etime`) VALUES
(1, 'Click And Talk', '2020-02-28', 'Auditorium', '10:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE IF NOT EXISTS `tbl_feedback` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `studentid` int(50) NOT NULL,
  `feedback` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_feedback`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_judge`
--

CREATE TABLE IF NOT EXISTS `tbl_judge` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `place` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_judge`
--

INSERT INTO `tbl_judge` (`id`, `name`, `contact`, `place`, `email`, `image`, `status`) VALUES
(1, 'Shilpa', '9898989899', 'pathanamthitta', 'shilpa@gmail.com', '/media/2018-02.webp', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE IF NOT EXISTS `tbl_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `username`, `password`, `usertype`) VALUES
(1, 'admin@gmail.com', 'admin', 'Admin'),
(2, 'akhil@gmail.com', 'akhil', 'Student'),
(3, 'remya@gmail.com', 'remya', 'Student'),
(4, 'avin@gmail.com', 'avin', 'Student'),
(5, 'anna@gmail.com', 'anna', 'Student'),
(6, 'nyna@gmail.com', 'nyna', 'Coordinator'),
(7, 'devak@gmail.com', 'devak', 'Coordinator'),
(8, 'jeeva@gmail.com', 'jeeva', 'Judge'),
(9, 'hima@gmail.com', 'hima', 'Judge'),
(10, 'devika@gmail.com', 'devika', 'Judge'),
(11, 'shyam@gmail.com', 'shyam', 'Student'),
(12, 'prashob@gmail.com', 'prashob', 'Coordinator'),
(13, 'sujith@gmail.com', 'sujith', 'Judge'),
(14, 'shyam@gmail.com', 'shyam', 'Student'),
(15, 'sruthy@gmail.com', 'sruthy', 'Coordinator'),
(16, 'shilpa@gmail.com', 'shilpa', 'Judge');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mark`
--

CREATE TABLE IF NOT EXISTS `tbl_mark` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `pid` int(50) NOT NULL,
  `eventname` varchar(30) NOT NULL,
  `judgeid` int(50) NOT NULL,
  `score` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_mark`
--

INSERT INTO `tbl_mark` (`id`, `pid`, `eventname`, `judgeid`, `score`) VALUES
(1, 1, 'Click And Talk', 1, '50');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_participants`
--

CREATE TABLE IF NOT EXISTS `tbl_participants` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `pid` int(50) NOT NULL,
  `eventid` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_participants`
--

INSERT INTO `tbl_participants` (`id`, `pid`, `eventid`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE IF NOT EXISTS `tbl_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(50) NOT NULL,
  `saddress` varchar(50) NOT NULL,
  `scontact` varchar(50) NOT NULL,
  `semail` varchar(50) NOT NULL,
  `idproof` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`id`, `sname`, `saddress`, `scontact`, `semail`, `idproof`, `status`) VALUES
(1, 'Shyam', 'idukki', '9898989899', 'shyam@gmail.com', '/media/748c4f1e0bf2de00da7cdae61eee15ae.jpg', '1');

-- --------------------------------------------------------

--
-- Table structure for table `winner`
--

CREATE TABLE IF NOT EXISTS `winner` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `pid` int(50) NOT NULL,
  `ename` varchar(50) NOT NULL,
  `score` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `winner`
--

INSERT INTO `winner` (`id`, `pid`, `ename`, `score`) VALUES
(1, 1, 'Click And Talk ', '50');
