from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpResponseRedirect
import pymysql
import datetime
from django.core.files.storage import FileSystemStorage
db=pymysql.connect(host='localhost',user='root',password='',database='dbitfest')
c=db.cursor()
def index(request):
    return render(request,"index.html")
def about(request):
    return render(request,"about.html")
def studentreg(request):
    s=""
    msg=""
    if(request.POST):
        cid=request.session["id"]
        name=request.POST.get("name")
        address=request.POST.get("address")
        contact=request.POST.get("contact")
        email=request.POST.get("email")
        password=request.POST.get("password")
        
        s="select count(*) from tbl_student where semail='"+str(email)+"'"
        c.execute(s)
        msg="Already Registered"
        i=c.fetchone()
        if(i[0]==0):
            img=request.FILES["idproof"]
            fs=FileSystemStorage()
            filename=fs.save(img.name,img)
            uploaded_file_url=fs.url(filename)
            s="insert into tbl_student (cid,sname,saddress,scontact,semail,idproof,status) values('"+str(cid)+"','"+str(name)+"','"+str(address)+"','"+str(contact)+"','"+str(email)+"','"+uploaded_file_url+"','0')"
            c.execute(s)
            
            db.commit()
            s="insert into tbl_login(username,password,usertype,status) values('"+str(email)+"','"+str(password)+"','Student','0')"
            c.execute(s)
            msg="Regitration Successfull"
            db.commit()
    return render(request,"studentregistration.html",{"msg":msg})
def login(request):
    msg=""
    if(request.POST):
        email=request.POST.get("username")
        password=request.POST.get("password")
        s="select count(*) from tbl_login where username='"+str(email)+"' and password='"+str(password)+"' and status='1'"
        c.execute(s)
        i=c.fetchone()
        if(i[0]==0):
            msg="User doesnt exist"
        else:
            s="select * from tbl_login where username='"+str(email)+"' and password='"+str(password)+"'  and status='1'"
            c.execute(s)
            y=c.fetchone()
            request.session['id']=y[0]
             
            if y[3]=='Admin':
                return HttpResponseRedirect("/adminhome")
            elif y[3]=='Student':
                s="select * from tbl_student where semail='"+str(email)+"' "
                
                c.execute(s)
                y=c.fetchone()
                request.session['id']=y[0]

                return HttpResponseRedirect("/studenthome")
            elif y[3]=='Coordinator':
                s="select * from tbl_coordinator where email='"+str(email)+"'"
                
                c.execute(s)
                y=c.fetchone()
                request.session['id']=y[0]
                return HttpResponseRedirect("/coordinatorhome")
            elif y[3]=='Judge':
                s="select * from tbl_judge where email='"+str(email)+"'"
                
                c.execute(s)
                y=c.fetchone()
                request.session['id']=y[0]
                return HttpResponseRedirect("/judgehome")
            elif y[3]=='College':
                s="select * from tbl_college where cemail='"+str(email)+"'"
                
                c.execute(s)
                y=c.fetchone()
                request.session['id']=y[0]
                return HttpResponseRedirect("/collegehome")
    return render(request,"login.html",{"msg":msg})
def adminhome(request):
    return render(request,"adminhome.html")
def studenthome(request):
    return render(request,"studenthome.html")
def judgehome(request):
    return render(request,"judgehome.html")
def coordinatorhome(request):
    return render(request,"coordinatorhome.html")
def approvestudents(request):
    c.execute("select * from tbl_login where status='0' and usertype='Student'")
    j=c.fetchall() 
    print(j)
    return render(request,"approvestudents.html",{"j":j})
def acceptstudent(request):
    id=request.GET.get("id")
    c.execute("select semail from tbl_student where id='"+str(id)+"'")
    data=c.fetchone()
    data1=data[0]
    print(data1)

    s="update tbl_login set status='1' where username='"+str(data1)+"'"
    c.execute(s)
    db.commit()
    print(s)
    return HttpResponseRedirect("/approvestudents")
def addcoordinator(request):
    s=""
    msg=""
    if(request.POST):
        name=request.POST.get("name")
        address=request.POST.get("address")
        contact=request.POST.get("contact")
        place=request.POST.get("place")
        email=request.POST.get("email")
        password=request.POST.get("password")
        s="select count(*) from tbl_coordinator where email='"+str(email)+"'"
        c.execute(s)
        i=c.fetchone()
        if(i[0]==0):
       
            s="insert into tbl_coordinator(name,address,contact,place,email,status) values('"+str(name)+"','"+str(address)+"','"+str(contact)+"','"+str(place)+"','"+str(email)+"','1')"
            c.execute(s)
            db.commit()
            s="insert into tbl_login(username,password,usertype,status) values('"+str(email)+"','"+str(password)+"','Coordinator','1')"
            c.execute(s)
            msg="Coordinator Added"
            db.commit()
    return render(request,"addcoordinator.html",{"msg":msg})
def addjudge(request):
    s=""
    msg=""
    if(request.POST):
        name=request.POST.get("name")
        
        contact=request.POST.get("contact")
        place=request.POST.get("place")
        email=request.POST.get("email")
        password=request.POST.get("password")
        
        s="select count(*) from tbl_judge where email='"+str(email)+"'"
        c.execute(s)
        i=c.fetchone()
        if(i[0]==0):
            img=request.FILES["image"]
            fs=FileSystemStorage()
            filename=fs.save(img.name,img)
            uploaded_file_url=fs.url(filename)
            s="insert into tbl_judge (name,contact,place,email,image,status) values('"+str(name)+"','"+str(contact)+"','"+str(place)+"','"+str(email)+"','"+uploaded_file_url+"','1')"
            c.execute(s)
            db.commit()
            s="insert into tbl_login(username,password,usertype,status) values('"+str(email)+"','"+str(password)+"','Judge','1')"
            msg="Judge Added"
            c.execute(s)
            db.commit()
    return render(request,"addjudge.html",{"msg":msg})
def addevent(request):
    s=""
    msg=""
    if(request.POST):
        name=request.POST.get("eventname")
        edate=request.POST.get("eventdate")
        venue=request.POST.get("place")
        time=request.POST.get("time")
        nump=request.POST.get("nump")
        s="select count(*) from tbl_event where ename='"+str(name)+"'"
        c.execute(s)
        i=c.fetchone()
        if(i[0]==0):
       
            s="insert into tbl_event(ename,edate,venue,etime,peoplenum,status) values('"+str(name)+"','"+str(edate)+"','"+str(venue)+"','"+str(time)+"','"+str(nump)+"','1')"
            c.execute(s) 
            msg="Event Added"   
            db.commit()
    return render(request,"addevent.html",{"msg":msg})
def viewevents(request):
    c.execute("select * from tbl_event where status='1' ")
    j=c.fetchall() 
    print(j)
    return render(request,"viewevents.html",{"j":j})
def participate(request):
    s=""
    msg=""
    participantid=request.session['id']
    eid=request.GET.get("id")
    participantid=request.session['id']
    u="select cid from tbl_college where cid in(select cid from tbl_student where id='"+str(participantid)+"')"
    c.execute(u)
    tt=c.fetchone()
    t=tt[0]
    print(t)
    s="select count(*) from tbl_participants where eventid='"+str(eid)+"' and pid='"+str(participantid)+"'"
    c.execute(s)
    msg="Already Participated"
    i=c.fetchone()
    if(i[0]==0):
       
        s="insert into tbl_participants(pid,eventid,cid) values('"+str(participantid)+"','"+str(eid)+"','"+str(t)+"')"
        c.execute(s)  
         
        db.commit()
        msg="Registered"
    return HttpResponseRedirect("/viewevents")
    # return render(request,"viewevents.html",{"msg":msg})    
def selectjudge():
    data=""
    c.execute("select * from tbl_judge")
    data=c.fetchall()
    return data
def selectevent():
    data=""
    c.execute("select * from tbl_event")
    data=c.fetchall()
    return data
def allocatejudge(request):
    m=""
    msg=""
    if(request.POST):
        
        eventid=request.POST.get("eventid")
        judgeid=request.POST.get("judgeid")
        m="select count(*) count from tbl_allocation where eventid='"+str(eventid)+"' and judgeid='"+str(judgeid)+"'"
        c.execute(m)
        msg="Already Allocated"
        i=c.fetchone()
        if(i[0]==0):
            m="insert into tbl_allocation(eventid,judgeid) values('"+str(eventid)+"','"+str(judgeid)+"')"
            c.execute(m)
            msg="Allocated"
            db.commit()
    name=selectjudge()
    ename=selectevent()
    return render(request,"allocatejudge.html",{"m":m,"ename":ename,"name":name,"msg":msg})
def viewallocation(request):
    judgeid=request.session['id']
    c.execute("SELECT tbl_event.id, tbl_event.`ename`,tbl_event.`edate`,tbl_event.`etime`,tbl_event.`venue`,tbl_event.`peoplenum` FROM tbl_judge,tbl_event,tbl_allocation WHERE tbl_judge.id=tbl_allocation.`judgeid` AND tbl_event.`id`=tbl_allocation.`eventid` AND judgeid='"+str(judgeid)+"' and tbl_event.status='1'")
    s=c.fetchall() 
    print(s)
    return render(request,"viewallocation.html",{"s":s})
# def plist(request):
#     # plistid=request.GET.get("id")
#     # ename=request.GET.get("ename")
#     s="SELECT tbl_student.id,tbl_student.`sname`,tbl_student.`scontact`,tbl_student.`idproof`,tbl_event.`ename` FROM tbl_student,tbl_event,tbl_participants WHERE tbl_student.`id`=tbl_participants.`pid` AND tbl_event.`id`=tbl_participants.`eventid`"
#     c.execute(s)
#     j=c.fetchall()
#     print(j)
#     return render(request,"plist.html",{"j":j})
def viewparticipants(request):
    c.execute("SELECT tbl_student.`sname`,tbl_student.`semail`,tbl_student.`idproof`,tbl_event.`ename` FROM tbl_student,tbl_event,tbl_participants WHERE tbl_student.`id`=tbl_participants.`pid` AND tbl_event.`id`=tbl_participants.`eventid` and tbl_event.status='1'")
    j=c.fetchall() 
    print(j)
    return render(request,"viewparticipant.html",{"j":j})
def viewwinner(request):
    return render(request,"viewwinner.html")
def viewmarks(request):
    studid=request.session['id']
    c.execute("SELECT tbl_mark.`eventname`, tbl_event.ename,tbl_mark.`score` FROM tbl_mark,tbl_student,tbl_event WHERE tbl_mark.pid=tbl_student.`id`AND tbl_student.`id`='"+str(studid)+"' and tbl_mark.eventname=tbl_event.id and tbl_event.status='1'")
    j=c.fetchall() 
    print(j)
    return render(request,"viewmarks.html",{"j":j})
# def viewwinnersstud(request):
#     c.execute("SELECT tbl_student.`sname`,winner.ename,winner.score FROM tbl_student,winner WHERE tbl_student.`id`=winner.pid")
#     j=c.fetchall() 
#     print(j)
#     return(request,"viewwinnersstud.html",{"j":j})
def addmarks(request):
    judgeid=request.session['id']
    m="SELECT tbl_event.`id`,tbl_event.`ename` FROM tbl_allocation,tbl_event WHERE tbl_event.id=tbl_allocation.`eventid` and tbl_allocation.judgeid='"+str(judgeid)+"' and tbl_event.status='1'"
    c.execute(m)
    # c.execute("SELECT tbl_student.`id`, tbl_student.`sname`,tbl_student.`idproof` ,tbl_event.`ename` FROM tbl_student,tbl_event,tbl_participants,tbl_allocation  WHERE tbl_student.`id`=tbl_participants.`pid` AND tbl_event.`id`=tbl_participants.`eventid` AND tbl_event.`ename`='Campzotica' AND tbl_allocation.`judgeid`='"+str(judgeid)+"'")
    j=c.fetchall() 
    print(j)
    return render(request,"addmarks.html",{"j":j})
def plist(request):
    id=request.GET.get("id")
    # ename=request.GET.get("ename")
    c.execute("SELECT tbl_participants.pid,tbl_event.`id`,tbl_student.`sname`,tbl_student.`idproof`,tbl_student.`scontact` FROM tbl_student,tbl_participants,tbl_event WHERE tbl_event.id=tbl_participants.`eventid` AND tbl_participants.pid=tbl_student.`id` and tbl_participants.eventid='"+str(id)+"' and tbl_event.status='1'")
    j=c.fetchall()
    print(j)
    return render(request,"plist.html",{"j":j})
def addmarksjudge(request):
    msg=""
    if(request.POST):

        pid=request.GET.get("id")
        eventname=request.GET.get("eid")
        judgeid=request.session['id']
        tscore=request.POST.get("tscore")
        s="select count(*) from tbl_mark where pid='"+str(pid)+"' and eventname='"+str(eventname)+"'"
        c.execute(s)
        msg="Already mark Added"
        i=c.fetchone()
        if(i[0]==0):
       
            s="insert into tbl_mark(pid,eventname,judgeid,score) values('"+str(pid)+"','"+str(eventname)+"','"+str(judgeid)+"','"+str(tscore)+"')"
            c.execute(s)  
            msg="Mark Added"  
            db.commit()
    return render(request,"addmarksjudge.html",{"msg":msg})
def addwinner(request):
    jid=request.session["id"]
    #c.execute("SELECT tbl_participants.`pid`,tbl_student.`sname`,tbl_student.`scontact`,tbl_mark.eventname,tbl_judge.`name` AS judgename,tbl_mark.`score` FROM tbl_participants,tbl_mark,tbl_judge,tbl_student,tbl_allocation WHERE tbl_student.`id`=tbl_participants.`pid` AND tbl_mark.`judgeid`=tbl_judge.`id` and tbl_mark.pid=tbl_participants.pid and tbl_allocation.judgeid='"+str(jid)+"'")
    c.execute("SELECT tbl_participants.`pid`,tbl_student.`sname`,tbl_student.`scontact`,tbl_mark.eventname,tbl_judge.`name` AS judgename,tbl_mark.`score` FROM tbl_participants,tbl_mark,tbl_judge,tbl_student,tbl_allocation WHERE tbl_student.`id`=tbl_participants.`pid` AND tbl_mark.`judgeid`=tbl_judge.`id` and tbl_mark.pid=tbl_participants.pid and tbl_allocation.judgeid='"+str(jid)+"' and tbl_allocation.judgeid=tbl_judge.id and tbl_student.cid=tbl_participants.cid and tbl_allocation.eventid=tbl_mark.eventname and tbl_allocation.eventid=tbl_participants.eventid")
    j=c.fetchall()
    print(j)
    return render(request,"addwinner.html",{"j":j})
def winner(request):
    pid=request.GET.get("id")
    ename=request.GET.get("ename")
    score=request.GET.get("score")
    s="select count(*) from winner where pid='"+str(pid)+"' and ename='"+str(ename)+"'"
    c.execute(s)
    msg="Already Added"
    i=c.fetchone()
    if(i[0]==0):
       
        s="insert into winner(pid,ename,score) values('"+str(pid)+"','"+str(ename)+"','"+str(score)+"')"
        c.execute(s)  
        msg="Winner..."  
        db.commit()
    return render(request,"addwinner.html",{"msg":msg})
def addfeedback(request):
    s=""
    msg=""
    if(request.POST):
        studentid=request.session['id']
        feedback=request.POST.get("feedback")
       
        s="insert into tbl_feedback(studentid,feedback) values('"+str(studentid)+"','"+str(feedback)+"')"
        msg="Feedback Added"
        c.execute(s)
        db.commit()
    return render(request,"addfeedback.html",{"msg":msg})
def viewfeedback(request):
    c.execute("SELECT tbl_student.`sname`,tbl_feedback.feedback FROM tbl_student,tbl_feedback WHERE tbl_student.id=tbl_feedback.studentid")
    j=c.fetchall() 
    print(j)
    return render(request,"viewfeedback.html",{"j":j})
def viewwinnerstudent(request):
    c.execute("SELECT tbl_student.`sname`,winner.ename,winner.score,tbl_event.ename FROM tbl_student,winner,tbl_event WHERE tbl_student.`id`=winner.pid and winner.ename=tbl_event.id and tbl_event.status='1'")
    j=c.fetchall() 
    print(j)
    return render(request,"viewwinnersstud.html",{"j":j})




# Create your views here.
def collegereg(request):
    s=""
    msg=""
    if(request.POST):
        name=request.POST.get("name")
        address=request.POST.get("address")
        contact=request.POST.get("contact")
        email=request.POST.get("email")
        password=request.POST.get("password")
        
        s="select count(*) from tbl_college where cemail='"+str(email)+"'"
        c.execute(s)
        
        i=c.fetchone()
        if(i[0]>0):
              msg="Already Registered"
        #     img=request.FILES["idproof"]
        #     fs=FileSystemStorage()
        #     filename=fs.save(img.name,img)
        #     uploaded_file_url=fs.url(filename)
        else:

            s="insert into tbl_college (cname,caddress,ccontact,cemail,status) values('"+str(name)+"','"+str(address)+"','"+str(contact)+"','"+str(email)+"','0')"
            c.execute(s)
            
            db.commit()
            s="insert into tbl_login(username,password,usertype,status) values('"+str(email)+"','"+str(password)+"','College','0')"
            c.execute(s)
            msg="Regitration Successfull"
            db.commit()
    return render(request,"collegereg.html",{"msg":msg})


def approvecolleges(request):
    c.execute("select * from tbl_login where status='0' and usertype='College'")
    j=c.fetchall() 
    print(j)
    return render(request,"approvecolleges.html",{"j":j})

def collegehome(request):
    
    return render(request,"collegehome.html")
def acceptcollege(request):
    id=request.GET.get("id")
    c.execute("select cemail from tbl_college where cid='"+str(id)+"'")
    data=c.fetchone()
    data1=data[0]
    print(data1)

    s="update tbl_login set status='1' where username='"+str(data1)+"'"
    c.execute(s)
    db.commit()
    return HttpResponseRedirect("/approvecolleges")

def cviewplist(request):
    cid=request.session["id"]
    s="select tbl_student.sname,tbl_event.ename from tbl_student,tbl_event,tbl_participants where tbl_student.id=tbl_participants.pid and tbl_student.cid=tbl_participants.cid and tbl_event.id=tbl_participants.eventid and tbl_participants.cid='"+str(cid)+"' and tbl_event.status='1'" 
    c.execute(s)
    data=c.fetchall()
    print(data)
    return render(request,"cviewplist.html",{"data":data})

def cviewwinner(request):
    cid=request.session["id"]
    s="select tbl_student.sname,tbl_event.ename,winner.score from tbl_student,tbl_event,winner where   tbl_event.id=tbl_event.id and tbl_student.cid='"+str(cid)+"' and winner.pid=tbl_student.id and winner.ename=tbl_event.id and tbl_event.status='1'" 
    c.execute(s)
    data=c.fetchall()
    print(data)
    return render(request,"cviewwinner.html",{"data":data})

def adminviewplist(request):
   
    s="select tbl_student.sname,tbl_event.ename,tbl_college.cname from tbl_student,tbl_event,tbl_participants,tbl_college where tbl_student.id=tbl_participants.pid and tbl_student.cid=tbl_college.cid and tbl_student.cid=tbl_participants.cid and tbl_event.id=tbl_participants.eventid and tbl_event.status='1'" 
    c.execute(s)
    data=c.fetchall()
    print(data)
    return render(request,"adminviewplist.html",{"data":data})

def adminviewwinner(request):
  
    s="select tbl_student.sname,tbl_event.ename,winner.score,tbl_college.cname from tbl_student,tbl_event,winner,tbl_college where   tbl_event.id=tbl_event.id and winner.pid=tbl_student.id and winner.ename=tbl_event.id and tbl_student.cid=tbl_college.cid and tbl_event.status='1'" 
    c.execute(s)
    data=c.fetchall()
    print(data)
    return render(request,"adminviewwinner.html",{"data":data})

def adminviewcolleges(request):
  
    s="select tbl_college.* from tbl_college where cemail in(select username from tbl_login where usertype='College' and status='1')"
    c.execute(s)
    data=c.fetchall()
    print(data)
    return render(request,"adminviewcolleges.html",{"data":data})

def adminviewcandidates(request):
  
    s="select tbl_student.*,tbl_college.cname from tbl_student,tbl_college where semail in(select username from tbl_login where usertype='Student' and status='1') and tbl_student.cid=tbl_college.cid"
    c.execute(s)
    data=c.fetchall()
    print(data)
    return render(request,"adminviewcandidates.html",{"data":data})
def adminviewevents(request):
    c.execute("select * from tbl_event where status='1'")
    data=c.fetchall()
    print(data)
    return render(request,"adminviewevents.html",{"data":data})

def deleteevent(request):
    eventid=request.GET.get("id")
    c.execute("update tbl_event set status='0' where id='"+str(eventid)+"'")
    db.commit()
    return HttpResponseRedirect('/adminviewevents')
