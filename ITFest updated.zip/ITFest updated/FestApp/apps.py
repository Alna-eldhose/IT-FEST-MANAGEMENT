from django.apps import AppConfig


class FestappConfig(AppConfig):
    name = 'FestApp'
